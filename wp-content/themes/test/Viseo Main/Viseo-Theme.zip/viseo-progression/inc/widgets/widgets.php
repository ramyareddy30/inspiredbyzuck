<?php
	get_template_part('inc/widgets/social-widget');
?>